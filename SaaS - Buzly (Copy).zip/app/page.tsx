import Cover from "./cover";

export default function Page() {
  return <Cover />;
}
